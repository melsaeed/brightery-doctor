"""Brightery Doctor Linux diagnostics."""
